import requests
import json
import pandas as pd
import xlwings as xw
#中国各省数据
cn_url = 'https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=localCityNCOVDataList,diseaseh5Shelf'
#中国每日
china_url = ' https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayListNew,chinaDayAddListNew&limit=365'
# wb = '"C:/Users/xuxiaolin/Desktop/data1.xls'
# China_Data = '"C:/Users/xuxiaolin/Desktop/data1.xls'

# 解析各省数据并生成表格
def table_cn(items_cn):
    app = xw.App(visible=True, add_book=False)
    wb = app.books.add()  # 打开Excel
    sht = wb.sheets['Sheet1']  # 建表
    sht.range('A1').value = '省份'
    sht.range('B1').value = '日期'
    sht.range('C1').value = '当日新增确诊'
    sht.range('D1').value = '当日新增无症状感染者'
    for i in range(34):
        province_data = []
        province_data = items_cn['areaTree'][0]['children']
        province_name = province_data[i]['name']  # 省份
        sht.range(f'A{i + 2}').value = province_name
        province_date = items_cn['lastUpdateTime'].split(' ')[0]  # 当前日期
        sht.range(f'B{i + 2}').value = province_date
        province_confirm_add = province_data[i]['today']['confirm']  # 当日新增确诊
        sht.range(f'C{i + 2}').value = province_confirm_add
        province_wzz_add = province_data[i]['today']['wzz_add']  # 当日新增无症状感染者
        sht.range(f'D{i + 2}').value = province_wzz_add
    wb.save(f'C:\\Users\\xuxiaolin\\Desktop\\中国各省疫请数据.xlsx')
    print("中国各省疫情数据表已存储至指定路径")


# 解析中国每日疫情数据并做成表格
def table_china_day(items_china):
    app = xw.App(visible=True, add_book=False)
    China_Data = app.books.add()
    sht = China_Data.sheets('Sheet1')  # 建表
    sht.range('A1').value = '日期'
    sht.range('B1').value = '当日新增'
    sht.range('C1').value = '当日新增无症状感染者'
    for i in range(365):
        item_dayadds = items_china['chinaDayAddListNew']
        item_dayadd = item_dayadds[i]
        year = item_dayadd['y']
        month, day = item_dayadd['date'].split('.')
        date = year + '-' + month + '-' + day    #日期
        sht.range(f'A{i + 2}').value = date
        china_confirm_add = item_dayadd['localConfirmadd']   #当日新增
        sht.range(f'B{i + 2}').value = china_confirm_add
        china_confirm_localinfectionadd = item_dayadd['localinfectionadd']   #当日新增无症状感染者
        sht.range(f'C{i + 2}').value = china_confirm_localinfectionadd
    China_Data.save(f'C:\\Users\\xuxiaolin\\Desktop\\中国每日疫情数据.xlsx')
    print("中国每日疫情数据表已存储至指定路径")


def main():
    resp = requests.get(cn_url) #请求中国各省疫情数据
    data1 = resp.json()['data']['diseaseh5Shelf']
    table_cn(data1)
    response = requests.get(china_url)  # 请求中国每日疫情数据
    data2 = response.json()['data']
    table_china_day(data2)

if __name__ == "__main__":
    main()
