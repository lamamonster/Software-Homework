from pyecharts.charts import Bar
import xlrd

data = xlrd.open_workbook('C:\\Users\\xuxiaolin\\Desktop\\中国各省疫请数据.xlsx')  # 打开本地excel表格
    # print(data) #显示文件的内存地址

table = data.sheets()[0]  # 拿出表格的第一个sheet
print(table.nrows)  # 显示多少行
print(table.ncols)  # 显示多少列
    # print(table.row_values(0)) #打印第几行内容
    # print(table.col_values(0)) #打印第几列内容

provinces = []  # 画图用的x轴，坐标是省份
adds = []  # 画图用的y轴，坐标当日新增
    # 循环输出每行内容
for i in range(2, table.nrows):
    a = table.row_values(i)  # 把第几行拿出来作为一个列表
    print(a)
    province = a[0]  # 省份提取加入province列表
    provinces.append(province)
    add = a[2]  # 当日新增提取加入add列表
    adds.append(add)
bar = Bar() #创建一个柱状图对象
bar.add_xaxis(province) #设置x轴
bar.add_yaxis('当日新增',add) #设置y轴和图标名
bar.render('中国各省疫情.html') #输出html文件来显示柱状图